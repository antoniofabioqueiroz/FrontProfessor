let course_Id = 0;

function listCourses() {
  console.log("listCourse() foi chamado pelo HTML");
  const courseTableBody = document.getElementById("courseTableBody");

  // Solicita a lista de cursos da API
  axios
    .get("https://professor-allocation-node-git.onrender.com/course/list")
    .then(function (response) {
      const courses = response.data; // Obtenha a lista de cursos da resposta da API

      courses.forEach(function (course) {
        var newRow = document.createElement("tr");
        newRow.innerHTML =
          '<td><span class="custom-checkbox"><input type="checkbox" class="checkbox" data-id="' +
          course.id +
          '"><label for="checkbox' +
          course.id +
          '"></label></span></td>' +
          '<td class="course-name">' +
          course.name +
          "</td>" +
          '<td><a href="#edit" class="edit" data-toggle="modal" data-id="' +
          course.id +
          '"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>' +
          '<a href="#delete" class="delete" data-toggle="modal" data-id="' +
          course.id +
          '"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a></td>';

        courseTableBody.appendChild(newRow);
      });

      // Adicione um evento de clique às checkboxes
      const checkboxes = document.querySelectorAll(".checkbox");
      checkboxes.forEach(function (checkbox) {
        checkbox.addEventListener("click", function () {
          if (checkbox.checked) {
            // O checkbox está selecionado, então você pode acessar o ID usando o atributo 'data-id'
            const courseId = checkbox.getAttribute("data-id");
            console.log("ID do curso selecionado: " + courseId);
          }
        });
      });

      // Adicione um evento de clique aos botões "Delete"
      const deleteButtons = document.querySelectorAll(".delete");
      deleteButtons.forEach(function (deleteButton) {
        deleteButton.addEventListener("click", function () {
          const courseId = deleteButton.getAttribute("data-id");
          console.log("ID do curso a ser excluído: " + courseId);
          // Chame a função de exclusão do curso passando o courseId
          deleteCourse(courseId);
        });
      });

      // Adicione um evento de clique aos botões "Editar"
      const updateButtons = document.querySelectorAll(".edit");
      updateButtons.forEach(function (updateButton) {
        updateButton.addEventListener("click", function () {
          const courseId = updateButton.getAttribute("data-id");
          console.log("ID do curso a ser atualizado: " + courseId);

          // Quando o botão "Editar" é clicado, você pode solicitar os detalhes do curso
          findById(courseId, function (courseName) {
            if (courseName) {
              document.getElementById("editCourseNameInput").value = courseName;
              console.log("Nome do curso: " + courseName);
            } else {
              console.log("Curso não encontrado ou erro ao buscar o curso.");
            }
          });
        });
      });
    })
    .catch(function (error) {
      console.error("Erro ao obter a lista de cursos: " + error);
    });
}

document.addEventListener("DOMContentLoaded", function () {
  listCourses();
});

function findById(courseId, callback) {
  let course_Id = Number(courseId);
  console.log("findById recebeu id: " + course_Id);
  axios
    .get(
      "https://professor-allocation-node-git.onrender.com/course/" + course_Id
    )
    .then(function (response) {
      console.log(response.data);
      const course = response.data;

      if (course && course.name) {
        callback(course.name);
      } else {
        callback(null);
      }
    })
    .catch(function (error) {
      console.log("Erro ao buscar o curso: " + error);
      callback(null);
    });
}

function deleteCourse(courseId) {
  let course_Id = Number(courseId);
  // Faça uma solicitação para excluir o curso com o ID especificado
  console.log(" delete course recebeu id : " + course_Id);
  axios
    .delete(
      "https://professor-allocation-node-git.onrender.com/course/" + course_Id
    )
    .then(function (response) {
      // Curso excluído com sucesso, você pode atualizar a lista de cursos ou fazer outras ações necessárias
      console.log("Curso com ID " + course_Id + " excluído com sucesso.");
    })
    .catch(function (error) {
      console.error("Erro ao excluir o curso: " + error);
    });
}
