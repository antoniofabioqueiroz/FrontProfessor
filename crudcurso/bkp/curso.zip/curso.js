// //versao apenas com a checkbox
// function listCourses() {
//   const courseTableBody = document.getElementById("courseTableBody");

//   // Use o Axios para fazer uma solicitação GET à API
//   axios
//     .get("https://professor-allocation-node-git.onrender.com/course/list")
//     .then(function (response) {
//       const courses = response.data; // Obtenha a lista de cursos da resposta da API

//       // Limpe o conteúdo atual da tabela
//       courseTableBody.innerHTML = "";

//       // Faz uma criaçao de linha para cada elemento da lista
//       courses.forEach(function (course) {
//         const row = document.createElement("tr"); // Cria uma nova linha <tr>
//         //Crie a célula <td> para o checkbox e preencha-a
//         const checkboxCell = document.createElement("td");
//         const checkbox = document.createElement("input");

//         //Also the checkbox and select box definition change to:
//         checkbox.type = "checkbox"; //Isso cria um elemento de célula de tabela <td>, que será usado para conter o checkbox.
//         checkbox.name = "options[]"; //Isso cria um elemento <input>, que será o checkbox em si. Estamos definindo o atributo name do checkbox como "options[]". Isso é comum quando você tem vários checkboxes em um formulário e deseja agrupá-los sob o mesmo nome, indicando que eles são opções.
//         checkbox.value = course.id; // O atributo value do checkbox está sendo definido com o id do curso, que provavelmente é um valor exclusivo associado a cada curso. Isso pode ser útil para identificar o curso selecionado posteriormente.
//         checkboxCell.appendChild(checkbox);

//         //colocar o nome do curso
//         const courseNameCell = document.createElement("td");
//         courseNameCell.textContent = course.name;

//         row.appendChild(checkboxCell); //adicionar na linha
//         row.appendChild(courseNameCell); //adicionar na linha
//         courseTableBody.appendChild(row);
//       });
//     })
//     .catch(function (error) {
//       console.error("Erro ao listar cursos:", error);
//     });
// }

//versao com a checkbox, e os botoes de deletar e  alterar
function listCourses() {
  const courseTableBody = document.getElementById("courseTableBody"); // Obtém o elemento <tbody>

  // Use o Axios para buscar a lista de cursos
  axios
    .get("https://professor-allocation-node-git.onrender.com/course/list")
    .then(function (response) {
      const courses = response.data;

      // Limpa o conteúdo atual da tabela
      courseTableBody.innerHTML = "";

      // Loop para adicionar cada curso à tabela
      courses.forEach(function (course) {
        const row = document.createElement("tr");
        const checkboxCell = document.createElement("td");
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.name = "options[]";
        checkbox.value = course.id;

        /*Estamos criando um elemento <label>. Um <label> é um rótulo descritivo para o elemento <input>.
         Neste caso, está associado ao checkbox para torná - lo mais acessível.
         O label permite que os usuários cliquem no rótulo para marcar ou desmarcar o checkbox
          contém a célula da tabela com o checkbox e seu rótulo associado.
          Isso cria uma coluna na tabela para a seleção de cursos com checkboxes e rótulos correspondentes.
        */
        const label = document.createElement("label");
        label.htmlFor = `checkbox${course.id}`; // O atributo htmlFor do label é definido com o valor do atributo id do input, que é uma convenção comum para associar o label ao input. Dessa forma, quando um usuário clica no rótulo, o checkbox correspondente é marcado/desmarcado.
        checkboxCell.appendChild(checkbox); // O elemento checkbox é adicionado como filho do checkboxCell, para que ele seja exibido na célula da tabela.
        checkboxCell.appendChild(label); //O elemento label também é adicionado como filho do checkboxCell, para que o rótulo esteja associado ao checkbox.

        // Crie a célula <td> para o nome do curso e preencha-a
        const courseNameCell = document.createElement("td");
        courseNameCell.textContent = course.name;

        // Crie a célula <td> para os botões de edição e exclusão
        const actionCell = document.createElement("td"); //  Isso cria um elemento de célula de tabela <td>, que será usado para conter os botões de ação (edição e exclusão) relacionados a um curso específico.
        const editLink = document.createElement("a"); // Aqui, estamos criando um elemento de âncora <a>, que será usado para o botão de edição.
        editLink.href = "#edit"; //Definimos o atributo href do elemento âncora como "#edit". Isso é usado para criar um link que, quando clicado, ativará um modal ou janela pop-up de edição. A string "#edit" é uma âncora interna que geralmente é usada como identificador para o modal correspondente.
        editLink.classList.add("edit"); // Adicionamos uma classe chamada "edit" ao elemento âncora. Essa classe provavelmente é usada para estilizar o botão de edição usando folhas de estilo CSS.
        editLink.setAttribute("data-toggle", "modal"); //  Definimos o atributo data-toggle do elemento âncora como "modal". Isso é usado para indicar que o link deve ser tratado como um controle para abrir um modal (janela pop-up) quando clicado.
        editLink.setAttribute("data-course-id", course.id); // Defina o ID do curso como um atributo personalizado
        editLink.innerHTML =
          '<i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i>'; // Aqui, estamos definindo o conteúdo interno do elemento âncora como um ícone de edição. O ícone é criado usando um elemento <i>, que é comumente usado para ícones. O atributo data-toggle é definido como "tooltip" para fornecer uma dica de ferramenta quando o cursor paira sobre o ícone. O texto "Edit" é usado como um título para a dica de ferramenta.
        const deleteLink = document.createElement("a"); //Este é um processo semelhante ao passo 2, mas estamos criando um novo elemento âncora para o botão de exclusão.
        deleteLink.href = "#delete"; // Definimos o atributo href do elemento âncora como "#delete", indicando que este link abrirá um modal de exclusão quando clicado.
        deleteLink.classList.add("delete"); // Da mesma forma que o passo editLink.classList.add("edit"), adicionamos uma classe "delete" ao elemento âncora para estilizá-lo.
        deleteLink.setAttribute("data-toggle", "modal"); //Definimos o atributo data-toggle do elemento âncora como "modal". Isso é usado para indicar que o link deve ser tratado como um controle para abrir um modal (janela pop-up) quando clicado.
        editLink.setAttribute("data-course-id", course.id); // Defina o ID do curso como um atributo personalizado
        deleteLink.innerHTML =
          '<i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i>'; //Aqui, estamos definindo o conteúdo interno do elemento âncora como um ícone de edição. O ícone é criado usando um elemento <i>, que é comumente usado para ícones. O atributo data-toggle é definido como "tooltip" para fornecer uma dica de ferramenta quando o cursor paira sobre o ícone. O texto "Edit" é usado como um título para a dica de ferramenta.

        // Adicione um manipulador de evento para o botão de exclusão (chama deleteCourse)
        deleteLink.addEventListener("click", function () {
          deleteCourse(course.id);
        });

        actionCell.appendChild(editLink); //inalmente, anexamos os elementos âncora (editLink e deleteLink) à célula da tabela (actionCell), para que os botões de edição e exclusão sejam incluídos na célula.
        actionCell.appendChild(deleteLink);

        // Adicione as células à linha
        row.appendChild(checkboxCell);
        row.appendChild(courseNameCell);
        row.appendChild(actionCell);

        // Adicione a linha à tabela
        courseTableBody.appendChild(row);
      });
    })
    .catch(function (error) {
      console.error("Erro ao listar cursos:", error);
    });
}

// Chame a função para listar os cursos após o carregamento do DOM
document.addEventListener("DOMContentLoaded", function () {
  listCourses();
});

// Chame a função para listar os cursos após o carregamento do DOM
document.addEventListener("DOMContentLoaded", function () {
  listCourses();
});

function saveCourse(event) {
  event.preventDefault(); // Impede o envio do formulário

  const courseNameInput = document.getElementById("courseName");
  const courseName = courseNameInput.value;

  axios
    .post("https://professor-allocation-node-git.onrender.com/course/new", {
      name: courseName,
    })
    .then(function (response) {
      console.log("Curso salvo com sucesso:", response.data);
      courseNameInput.value = ""; // Limpa o campo do nome do curso
    })
    .catch(function (error) {
      console.error("Erro ao salvar curso:", error);
    });
}

// Função para atualizar um curso

// Adicione um ouvinte de eventos para o botão "Atualizar Curso"
document.addEventListener("DOMContentLoaded", function () {
  const updateCourseButton = document.getElementById("updateCourseButton");
  updateCourseButton.addEventListener("click", updateCourse);
});

function updateCourse(event) {
  event.preventDefault(); // Impede o envio do formulário

  const updateCourseIdInput = document.getElementById("updateCourseId");
  const courseId = updateCourseIdInput.value; // Recupere o ID do curso do campo de entrada

  // ...

  // Você pode usar courseId na solicitação para atualizar o curso
  axios
    .put(
      `https://professor-allocation-node-git.onrender.com/course/update/${courseId}`,
      { name: newCourseName }
    )
    .then(function (response) {
      // ...
    })
    .catch(function (error) {
      // ...
    });
}

// funcao de deletar
document.addEventListener("DOMContentLoaded", function () {
  // Adicione um ouvinte de eventos para o botão "Deletar Curso"
  const deleteCourseButton = document.getElementById("deleteCourseButton");
  deleteCourseButton.addEventListener("click", deleteCourse);
});

function deleteCourse() {
  // Obtenha o valor do ID do curso a ser deletado
  const deleteCourseIdInput = document.getElementById("deleteCourseId");
  const courseId = deleteCourseIdInput.value;

  // Realize uma solicitação DELETE para a API para deletar o curso com o ID especificado
  axios
    .delete(
      `https://professor-allocation-node-git.onrender.com/course/${courseId}`
    )
    .then(function (response) {
      console.log("Curso deletado com sucesso:", response.data);

      // Limpe o campo de entrada
      courseIdInput.value = "";

      // Atualize a lista de cursos após a exclusão
      listCourses();
    })
    .catch(function (error) {
      console.error("Erro ao deletar curso:", error);
    });
}
