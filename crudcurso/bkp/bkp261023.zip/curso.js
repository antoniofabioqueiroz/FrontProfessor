function listCourses() {
  console.log("listCourses() foi chamado!");
  const courseTableBody = document.getElementById("courseTableBody");

  // Limpe a tabela antes de adicionar novas linhas
  courseTableBody.innerHTML = "";

  // Solicita a lista de cursos da API
  axios
    .get("https://professor-allocation-node-git.onrender.com/course/list")
    .then(function (response) {
      const courses = response.data; // Obtenha a lista de cursos da resposta da API

      courses.forEach(function (course) {
        var newRow = document.createElement("tr");
        newRow.innerHTML =
          '<td><span class="custom-checkbox"><input type="checkbox" class="checkbox" data-id="' +
          course.id +
          '"><label for="checkbox' +
          course.id +
          '"></label></span></td>' +
          '<td class="course-name">' +
          course.name +
          "</td>" +
          '<td><a href="#edit" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>' +
          '<a href="#delete" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a></td>';

        courseTableBody.appendChild(newRow);
      });

      // Adicione um evento de clique às checkboxes
      courseTableBody.addEventListener("click", function (event) {
        if (event.target.classList.contains("checkbox")) {
          // A checkbox foi clicada
          const checkbox = event.target;
          const courseId = checkbox.getAttribute("data-id");
          console.log("ID do curso selecionado: " + courseId);
          // Faça o que você precisa com o ID, como enviar uma solicitação para editar ou excluir
        }
      });
    })
    .catch(function (error) {
      console.error("Erro ao obter a lista de cursos: " + error);
    });
}

document.addEventListener("DOMContentLoaded", function () {
  listCourses();
});
